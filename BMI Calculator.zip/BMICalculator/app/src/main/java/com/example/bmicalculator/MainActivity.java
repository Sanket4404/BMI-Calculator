package com.example.bmicalculator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView result_bmi;
        EditText edtweight, edthtft, edthtin;
        Button cal_bmi;
        LinearLayout linearmain;


        edtweight = findViewById(R.id.edtweight);
        edthtft  = findViewById(R.id.edthtft);
        edthtin = findViewById(R.id.edthtin);
        result_bmi = findViewById(R.id.result_bmi);
        cal_bmi = findViewById(R.id.cal_bmi);
        linearmain = findViewById(R.id.linearmain);

        cal_bmi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int wt  = Integer.parseInt(edtweight.getText().toString());
                int ft = Integer.parseInt( edthtft.getText().toString());
                int in = Integer.parseInt( edthtin.getText().toString());


                int total_In = ft*12 + in;

                double total_cm = total_In * 2.53;

                double totalM = total_cm / 100;

                double bmi = wt / (totalM * totalM);

                if (bmi > 25)
                {
                    result_bmi.setText("You're Overweight");
                    linearmain.setBackgroundColor(getResources().getColor(R.color.red));
                }
                else if (bmi < 18 ) {
                    result_bmi.setText("You're Underweight");
                    linearmain.setBackgroundColor(getResources().getColor(R.color.blue));
                }else {
                    result_bmi.setText("You're Healthy ");
                    linearmain.setBackgroundColor(getResources().getColor(R.color.green));

                }

            }
        });





    }
}